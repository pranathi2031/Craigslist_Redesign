Craigslist Redesign:

This project is about of Craigslist redesign mainly focusing on the home and discussions page.
Below link has more about background research, survey, interviews and other implemetation data.

Docmentation: https://docs.google.com/document/d/12Gov2ximjS6oqCSjuhE20YCViUwXsR4xO2u6jGBcCwQ/edit?usp=sharing

Demo: https://drive.google.com/file/d/1tA0EIug3KoKrNM60LyamOSijfVg2Wt9E/view?usp=sharing
